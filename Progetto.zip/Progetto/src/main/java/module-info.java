module com.example.segreteria.progetto {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.sql;
    requires mysql.connector.j;

    opens com.example.segreteria to javafx.fxml;
    opens command.pattern;
    exports com.example.segreteria;
    exports com.example.segreteria.studente;
    opens com.example.segreteria.studente to javafx.fxml;
    exports com.example.segreteria.docente;
    exports com.example.segreteria.segreteria;
    opens com.example.segreteria.segreteria to javafx.fxml;
    opens singleton.pattern;
    opens com.example.segreteria.docente;
    opens com.example.segreteria.corso;
    exports com.example.segreteria.corso;
}