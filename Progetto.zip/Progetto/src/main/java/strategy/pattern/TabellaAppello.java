package strategy.pattern;

import com.example.segreteria.corso.Appello;
import singleton.pattern.SessionStu;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutte le categorie contenute nel database.
 */
public class TabellaAppello implements Tabella<Appello> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * Appello.
     */
    @FXML
    private ObservableList<Appello> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutti gli appelli presenti nel database.
     */
    public TabellaAppello() {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo appello.
     * gli appelli restituiti sono solo quelli con data maggiore alla data corrente e il corso associato corrisponda allo studente loggato
     * infine si andranno ad escludere anche gli appelli degli esami che lo studente ha gia passato o di cui è gia prenotato
     */
    @Override
    public ObservableList<Appello> crea() {

        try {
            Database db = new Database();
            String sql = "SELECT * FROM appello WHERE appello.data > CURRENT_DATE and corso ='" + SessionStu.getIstanza().getStudente().getPianoStudi() + "' and nome NOT IN (SELECT nome FROM esame_superato WHERE matricolafk = '" + SessionStu.getIstanza().getStudente().getMatricola() + "') and" +
                    " appello.id not in (select idappellofk from prenotazione where matricolafk = " + SessionStu.getIstanza().getStudente().getMatricola() + ")";
            ResultSet rs = db.query(sql);

            while (rs.next()) {
                data.add(new Appello(rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getString(5), rs.getString(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}