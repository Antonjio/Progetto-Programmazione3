package strategy.pattern;

import com.example.segreteria.corso.Esame;
import singleton.pattern.SessionStu;
import singleton.pattern.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

import java.sql.ResultSet;

/**
 * Classe che rappresenta la tabella degli esami che lo studente deve sostenere
 */
    public class TabellaEsame implements Tabella<Esame> {
        @FXML
        private ObservableList<Esame> data;

        public TabellaEsame() {
            data = FXCollections.observableArrayList();
        }

        /**
         * Metodo che permette di popolare l'ObservableList con oggetti di tipo esame.
         * gli esami restituiti sono solo quelli che lo studente deve fare secondo il suo piano di studi
         * */
        @Override
        public ObservableList<Esame> crea() {
            try {
                Database db = new Database();
                String q = "select nome, cfu,cds from esame where cds = '" + SessionStu.getIstanza().getStudente().getPianoStudi()+"'";
                ResultSet rs = db.query(q);

                while (rs.next()) {
                    data.add(new Esame(rs.getString(1), rs.getInt(2)));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return data;
        }
    }
