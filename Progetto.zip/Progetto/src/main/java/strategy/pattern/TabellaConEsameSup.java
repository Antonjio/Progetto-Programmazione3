package strategy.pattern;

import com.example.segreteria.corso.Esame;
import singleton.pattern.SessionStu;
import singleton.pattern.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

import java.sql.ResultSet;

/**
 * Classe che implementa l'interfaccia Tabella e permette di popolare una tabella con gli esami superati ma non accettati
 */
public class TabellaConEsameSup implements Tabella<Esame> {
    @FXML
    private ObservableList<Esame> data;

    public TabellaConEsameSup() {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo esame.
     * gli esami restituiti sono solo quelli che lo studente ha superato ma non accettato e che quindi deve scegliere cosa fare
     * */
    @Override
    public ObservableList<Esame> crea() {
        try {
            Database db = new Database();
            String q = "select esame.nome, voto, cfu from esame join esame_superato on esame.nome = esame_superato.nome where matricolafk = '"
                    + SessionStu.getIstanza().getStudente().getMatricola()+"' and confermato = 0";
            ResultSet rs = db.query(q);

            while (rs.next()) {
                data.add(new Esame(rs.getString(1), rs.getInt(3),rs.getInt(2)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}
