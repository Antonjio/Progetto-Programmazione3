package strategy.pattern;
import javafx.collections.ObservableList;
/**
 * Questa classe permette di decidere quale strategia adottare(Context), in base al tipo di tabella che si sceglie di creare,
 */
public class TipoTabella<E> {
    /**
     * Variabile istanza privata che rappresente un oggetto di tipo Tabella.
     */
    private Tabella<E> tab;

    public TipoTabella(Tabella<E> x)
    {
        tab = x;
    }

    /**
     * Metodo che ritorna la lista di elementi da inserire nella tabella
     */
    public ObservableList<E> getElements()
    {
        return tab.crea();
    }
}