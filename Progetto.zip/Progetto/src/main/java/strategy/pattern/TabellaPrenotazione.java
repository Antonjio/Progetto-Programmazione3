package strategy.pattern;

import com.example.segreteria.corso.Appello;
import singleton.pattern.SessionStu;
import singleton.pattern.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

import java.sql.ResultSet;

/**
 * classe per la creazione della tabella prenotazione
 */
public class TabellaPrenotazione implements Tabella<Appello> {
    @FXML
    private ObservableList<Appello> data;

    public TabellaPrenotazione() {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo appello.
     * le prenotazioni restituite sono solo quelli che non sono scaduti
     * */
    @Override
    public ObservableList<Appello> crea() {
            try {
                Database db = new Database();
                    String sql = "Select idappellofk,appello.nome, appello.data from prenotazione join appello on idappellofk = id where matricolafk= '"+SessionStu.getIstanza().getStudente().getMatricola()+ "' and appello.data > CURRENT_TIME";
                    ResultSet rs = db.query(sql);

                    while (rs.next()) {
                        data.add(new Appello(rs.getInt(1), rs.getString(2),
                                rs.getString(3)));
                    }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}
