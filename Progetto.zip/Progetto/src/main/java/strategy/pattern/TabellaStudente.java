package strategy.pattern;

import command.pattern.Studente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;
/**
 * classe per la creazione della tabella studente
 */
public class TabellaStudente  implements Tabella<Studente> {

    @FXML
    private ObservableList<Studente> data;

    public TabellaStudente() {
        data = FXCollections.observableArrayList();
    }


    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo studente.
     * */
    @Override
    public ObservableList<Studente> crea() {
        try {
            Database db = new Database();

                String sql = "Select * from studente";
                ResultSet rs = db.query(sql);
                while (rs.next()) {
                    data.add(new Studente(rs.getInt(1), rs.getString(2),
                            rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
                }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}