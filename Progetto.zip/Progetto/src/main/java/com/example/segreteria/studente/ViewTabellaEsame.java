package com.example.segreteria.studente;

import com.example.segreteria.corso.Esame;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import strategy.pattern.TabellaEsame;
import strategy.pattern.TipoTabella;

import java.io.IOException;

/**classe per la visualizzazione degli esami del proprio piano di studi
 */
public class ViewTabellaEsame {
    /**
     * colonna per la visualizzazione dei cfu dell'esame
     */
    @FXML
    private TableColumn<Esame, Integer> cfuTab;

    /**
     * tabella per la visualizzazione degli esami del proprio piano di studi
     */
    @FXML
    private TableView<Esame> tableViewEsame;

    /**
     * colonna per la visualizzazione del nome dell'esame
     */
    @FXML
    private TableColumn<Esame, String> nomeEsameTab;


    /**inizializzo le colonne per la visualizzazione degli esami del proprio piano di studi
     */
    @FXML
    void initialize(){

        nomeEsameTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cfuTab.setCellValueFactory(new PropertyValueFactory<>("cfu"));
        TipoTabella<Esame> tab = new TipoTabella<>(new TabellaEsame());
        tableViewEsame.setItems(tab.getElements());
    }
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/studente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**funzione per l'apertura della scena degli esami convalidati
     * @param event evento che scatena la funzione
     * @throws IOException eccezione che viene lanciata se non trova il file fxml
     */
    @FXML
    void openEsamiSuperati(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/viewEsameSup.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

}
