package com.example.segreteria.corso;

/**
 * Classe che rappresenta un esame
 */
public class Esame {
    private int matricolaStudente;
    private int voto;
    private String nome;
    private int cfu;
    private String corso;

    public Esame() {
    }

    public Esame(String nome, int cfu, int voto) {
        this.nome = nome;
        this.cfu = cfu;
        this.voto = voto;
    }

    public Esame(String nome, int cfu) {
        this.nome = nome;
        this.cfu = cfu;
    }

    public int getMatricolaStudente() {
        return matricolaStudente;
    }

    public int getCfu() {
        return cfu;
    }

    // Metodo setter per cfu
    public void setCfu(int cfu) {
        this.cfu = cfu;
    }

    // Metodo getter per corso
    public String getCorso() {
        return corso;
    }

    // Metodo setter per corso
    public void setCorso(String corso) {
        this.corso = corso;
    }

    public int getVoto() {
        return voto;
    }

    public String getNome() {
        return nome;
    }

    public void setVoto(int voto) {
        this.voto = voto;
    }

    public void setMatricolaStu(int matricola) {
        this.matricolaStudente = matricola;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}

