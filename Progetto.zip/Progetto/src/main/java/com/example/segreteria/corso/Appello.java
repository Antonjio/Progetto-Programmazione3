package com.example.segreteria.corso;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Questa classe rappresenta un appello d'esame.
 */

public class Appello {
    private int id;
    private String nome;
    private java.sql.Date data;
    private String corso;
    private String docente;

    public Appello() {
    }

    /**
     * Costruttore con parametri per id, nome e data (con gestione dell'eccezione ParseException)
     * all'interno del costruttore c'è la funzione parse della classe SimpleDataFormat per trasformare una stringa in una data.
     * questo costruttore è stato usato per visualizzare gli appelli disponibili.
     *
     * @param id   id dell'appello
     * @param nome nome dell'appello
     * @param data data dell'appello
     * @throws ParseException eccezione che viene lanciata quando si verifica un errore durante il parsing di una stringa in una data
     */

    public Appello(int id, String nome, String data) throws ParseException {
        this.id = id;
        this.nome = nome;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(data);
        // Converti java.util.Date in java.sql.Date
        this.data = new java.sql.Date(utilDate.getTime());

    }

    /**
     * Costruttore con parametri per id, nome e data (con gestione dell'eccezione ParseException), nome corso e email docente.
     * all'interno del costruttore c'è la funzione parse della classe SimpleDataFormat per trasformare una stringa in una data.
     * questo costruttore è stato usato principalmente per l'inserimento di un nuovo appello nel db
     *
     * @param id      id dell'appello
     * @param nome    nome dell'appello
     * @param data    data dell'appello
     * @param corso   nome del corso
     * @param docente email del docente
     * @throws ParseException eccezione che viene lanciata quando si verifica un errore durante il parsing di una stringa in una data
     */
    public Appello(int id, String nome, String data, String corso, String docente) throws ParseException {
        this.id = id;
        this.nome = nome;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(data);
        // Converti java.util.Date in java.sql.Date
        this.data = new java.sql.Date(utilDate.getTime());
        this.corso = corso;
        this.docente = docente;

    }

    public void setCorso(String corso) {
        this.corso = corso;
    }

    // Metodo get per la variabile corso
    public String getCorso() {
        return corso;
    }

    // Metodo set per la variabile docente
    public void setDocente(String docente) {
        this.docente = docente;
    }

    // Metodo get per la variabile docente
    public String getDocente() {
        return docente;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDataAppello(String data) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(data);
        // Converti java.util.Date in java.sql.Date
        this.data = new java.sql.Date(utilDate.getTime());
    }

    public java.sql.Date getData() {
        return data;
    }
}
