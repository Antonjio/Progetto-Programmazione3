
package com.example.segreteria.studente;

import com.example.segreteria.corso.Esame;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import strategy.pattern.TabellaEsameSup;
import strategy.pattern.TipoTabella;

import java.io.IOException;

/**classe che gestisce la view della tabella degli esami superati
 *
 */
public class ViewTabellaEsameSup {
    /**
     * colonna cfu
     */
    @FXML
    private TableColumn<Esame, Integer> cfuTab;
/**
     * tabella esami superati
     */
    @FXML
    private TableView<Esame> tableViewEsame;

    /**
     * colonna nome esame
     */
    @FXML
    private TableColumn<Esame, String> nomeEsameTab;

    /**
     * colonna voto
     */
    @FXML
    private TableColumn<Esame, Integer> votoTab;

    @FXML
    void initialize() {

        nomeEsameTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        votoTab.setCellValueFactory(new PropertyValueFactory<>("voto"));
        cfuTab.setCellValueFactory(new PropertyValueFactory<>("cfu"));
        TipoTabella<Esame> tab = new TipoTabella<>(new TabellaEsameSup());
        tableViewEsame.setItems(tab.getElements());
    }

    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/viewEsame.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }
}