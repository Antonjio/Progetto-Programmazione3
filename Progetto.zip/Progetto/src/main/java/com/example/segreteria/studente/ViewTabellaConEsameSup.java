package com.example.segreteria.studente;


import command.pattern.*;
import com.example.segreteria.corso.Esame;
import singleton.pattern.SessionStu;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import strategy.pattern.TabellaConEsameSup;
import strategy.pattern.TipoTabella;

import java.io.IOException;

/**classe che gestisce la tabella degli esami da convalidare
 */
public class ViewTabellaConEsameSup {
    /**
     * colonna che continene i cfu dell'esame
     */
    @FXML
    private TableColumn<Esame, Integer> cfuTab;
    /**
     * tabella che contiene gli esami da convalidare
     */

    @FXML
    private TableView<Esame> tableViewEsame;

    /**
     * colonna che contiene il nome dell'esame
     */
    @FXML
    private TableColumn<Esame, String> nomeEsameTab;

    /**
     * colonna che contiene il voto dell'esame
     */
    @FXML
    private TableColumn<Esame, Integer> votoTab;

    /**
     * esame selezionato
     */
    private Esame selectedEsame;

    /**
     * bottone che permette di accetta il voto
     */
    @FXML
    private Button accetta;

    /**
     * bottone che permette di rifiutare il voto
     */
    @FXML
    private Button rifiuta;

    /**inizializzo le colonne della tabella degli esami da convalidare
     */
    @FXML
    void initialize(){
        accetta.setVisible(false);
        rifiuta.setVisible(false);

        nomeEsameTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        votoTab.setCellValueFactory(new PropertyValueFactory<>("voto"));
        cfuTab.setCellValueFactory(new PropertyValueFactory<>("cfu"));
        TipoTabella<Esame> tab = new TipoTabella<>(new TabellaConEsameSup());
        tableViewEsame.setItems(tab.getElements());
        tableViewEsame.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedEsame = newSelection;
                accetta.setVisible(true);
                rifiuta.setVisible(true);
            } else {
                selectedEsame = null;
            }
        });
    }

    /**
    * funzione che gestisce il caso in cui lo studente accetta l'esame andando a creare un oggetto di tipo AccettaCommand
    * per poi essere inserito all'interno di una coda della segreteria tramite la funzione "placeScelta"
    * e infine convalidato tramite il metodo "executeScelta"*/
    @FXML
    void accept() throws Exception {
        Scelta accettaCommand = new AccettaCommand(SessionStu.getIstanza().getStudente(), selectedEsame);
        Segreteria segreteria = new Segreteria();
        segreteria.placeScelta(accettaCommand);
        segreteria.executeScelta();
        tableViewEsame.getItems().remove(selectedEsame);
            if (tableViewEsame.getItems().isEmpty()){
                accetta.setVisible(false);
                rifiuta.setVisible(false);
            }
    }
    /**
     * funzione che gestisce il caso in cui lo studente rifiuta l'esame andando a creare un oggetto di tipo RifiutaCommand
     * per poi essere inserito all'interno di una coda della segreteria tramite la funzione "placeScelta"
     * e infine rifiutato tramite il metodo "executeScelta"*/
    @FXML
    void reject() throws Exception {
        Scelta rifiutaCommand = new RifiutaCommand(SessionStu.getIstanza().getStudente(), selectedEsame);
        Segreteria segreteria = new Segreteria();
        segreteria.placeScelta(rifiutaCommand);
        segreteria.executeScelta();
        tableViewEsame.getItems().remove(selectedEsame);
        if (tableViewEsame.getItems().isEmpty()){
            accetta.setVisible(false);
            rifiuta.setVisible(false);
        }
    }


    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/studente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

}