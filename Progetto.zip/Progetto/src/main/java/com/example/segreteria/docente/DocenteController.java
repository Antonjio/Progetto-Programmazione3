package com.example.segreteria.docente;

import com.example.segreteria.corso.Appello;
import com.example.segreteria.corso.Esame;
import singleton.pattern.SessionDoc;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import javafx.scene.control.Alert;
/**
 * Controller per la gestione delle funzioni del docente
 */
public class DocenteController {
    /**
     * campo per l'inserimento del nome dell'appello
     */
    @FXML
    private TextField nomeAppello;

    /**
     * campo per l'inserimento della data dell'appello
     */

    @FXML
    private TextField dataAppello;


    /**
     * campo per l'inserimento del voto
     */

    @FXML
    private TextField voto;

    /**
     * campo per l'inserimento del nome dell'esame
     */
    @FXML
    private TextField nomeesame;

    /**
     * campo per l'inserimento della matricola dello studente
     */

    @FXML
    private TextField matricolavoto;

    /**
     * oggetto di tipo Database per la connessione al database
     */
    private Database db;

    //connessione al db come prima operazione all'apertura della scena
    @FXML
    void initialize(){

        try {
            db = new Database();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**funzione di logout e ritorno in homepage
     * @param event evento che scatena la funzione
     * @throws IOException eccezione in caso di errore
     */

    @FXML
    void logout(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/homepage.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**funzione per tornare alla schermata del docente
     * @param event evento che scatena la funzione
     * @throws IOException eccezione in caso di errore
     */
    @FXML
    void indietro(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/docente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**funzione per aprire la scena per l'inserimento di un nuovo appello
     * @param event evento che scatena la funzione
     * @throws IOException eccezione in caso di errore
     */

    @FXML
    void openAppello(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/newappello.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**funzione per aprire la scena per l'inserimento di un nuovo voto ad un esame
     * @param event evento che scatena la funzione
     * @throws IOException eccezione in caso di errore
     */
    @FXML
    void openVoto(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/newvoto.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**funzione per inserire un nuovo appello andando a controllare che l'appello sia associato ad un esame esistente
    nel piano di studi relativo al docente con gestione di errore nel caso in cui l'esame non viene trovato.
    */
    @FXML
    void newAppello() {
        try {
            Appello appello = new Appello();
            appello.setNome(nomeAppello.getText().toUpperCase());
            appello.setDataAppello(dataAppello.getText());
            String sql = "Select * from docente where email = '" + SessionDoc.getIstanza().getDocente().getEmail() + "'";
            ResultSet resultSet = db.query(sql);

            if (resultSet.next()) {
                String corso = resultSet.getString("corso");
                SessionDoc.getIstanza().getDocente().setCorso(corso);
                String q = "insert into appello (nome, data, docente, corso)" + "values (?,?,?,?)";
                PreparedStatement preparedStatement = db.insert(q);

                preparedStatement.setString(1, appello.getNome());
                preparedStatement.setDate(2, appello.getData());
                preparedStatement.setString(3, SessionDoc.getIstanza().getDocente().getEmail());
                preparedStatement.setString(4, SessionDoc.getIstanza().getDocente().getCorso());

                preparedStatement.execute();
                nomeAppello.clear();
                dataAppello.clear();
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Inserito");
                alert.setHeaderText(null);
                alert.setContentText("Appello inserito correttamente");
                alert.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Errore");
                alert.setHeaderText(null);
                alert.setContentText("Corso non trovato");
            }

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setContentText("Non è stato possibile inserire l'appello");
            alert.show();
            System.out.println("ERRORE: " + e.getMessage());
        }

    }
    /**
    * Funzione per l'inserimento di un voto ad uno studente con gestione di errore nel caso in cui
    * il voto sia inferiore di 18 e nel caso in cui lo studente non fosse prenotato all'esame
    * se viene inserito un voto il docente provvede alla cancellazione delle prenotazioni a quel esame da parte dello studente
    * */
    @FXML
    void newvoto(){
        try {
            Esame esame = new Esame();
            esame.setNome(nomeesame.getText().toUpperCase());
            esame.setVoto(Integer.parseInt(voto.getText()));
            esame.setMatricolaStu(Integer.parseInt(matricolavoto.getText()));
            String sql = "select * from appello join prenotazione on prenotazione.idappellofk = appello.id where appello.nome = '"+esame.getNome()+"' and prenotazione.matricolafk = "+esame.getMatricolaStudente();
            ResultSet resultSet = db.query(sql);
            if (resultSet.next()) {
                if (esame.getVoto()>17){
                String q = "insert into esame_superato (nome, voto, matricolafk,confermato)" + "values (?,?,?,?)";
                PreparedStatement preparedStatement = db.insert(q);

                preparedStatement.setString(1, esame.getNome());
                preparedStatement.setInt(2, esame.getVoto());
                preparedStatement.setInt(3, esame.getMatricolaStudente());
                preparedStatement.setInt(4, 0);
                preparedStatement.execute();
                nomeesame.clear();
                voto.clear();
                matricolavoto.clear();
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Inserito");
                alert.setHeaderText(null);
                alert.setContentText("Voto inserito correttamente");
                alert.show();
                String delete = "delete from prenotazione where matricolafk = '"+esame.getMatricolaStudente()+"' and idappellofk in (" +
                        "select id from appello where nome = '"+esame.getNome()+"')";
                try {
                    db.update(delete);
                }catch (Exception e){
                    e.printStackTrace();
                }
                }else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Errore");
                    alert.setHeaderText(null);
                    alert.setContentText("Il voto deve essere compreso tra 18 e 30");
                    alert.show();
                }
            }else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Errore");
                alert.setHeaderText(null);
                alert.setContentText("Studente non prenotato all'appello");
                alert.show();
            }
        }catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setContentText("Non è stato possibile inserire l'esito dell'esame");
            alert.show();
            System.out.println("ERRORE: " + e.getMessage());
        }
    }
}
