package com.example.segreteria.segreteria;

import command.pattern.Studente;
import singleton.pattern.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import strategy.pattern.TabellaStudente;
import strategy.pattern.TipoTabella;

import java.io.IOException;
import java.sql.ResultSet;

/**
    * Classe che gestisce la ricerca degli studenti
    */
public class SegreteriaSearch {
    /**
     * campo di testo per la ricerca tramite matricola
     */
    @FXML
    private TextField searchMatricola;

    /**
     * campo di testo per la ricerca tramite nome
     */

    @FXML
    private TextField searchNome;

    /**
     * campo di testo per la ricerca tramite cognome
     */
    @FXML
    private TextField searchCognome;

    /**
     * colonna per la visualizzazione della residenza degli studenti
     */
    @FXML
    private TableColumn<Studente, String> residenzaTab;

    /**
     * tabella per la visualizzazione degli studenti
     */

    @FXML
    private TableView<Studente> tableViewStudente;

    /**
     * colonna per la visualizzazione del cognome degli studenti
     */

    @FXML
    private TableColumn<Studente, String> cognomeTab;

    /**
     * colonna per la visualizzazione della matricola degli studenti
     */
    @FXML
    private TableColumn<Studente, String> matricolaTab;

    /**
     * colonna per la visualizzazione della data di nascita degli studenti
     */
    @FXML
    private TableColumn<Studente, java.sql.Date> datanascitaTab;

    /**
     * colonna per la visualizzazione del piano di studi degli studenti
     */
    @FXML
    private TableColumn<Studente, String> cdsTab;

    /**
     * colonna per la visualizzazione del nome degli studenti
     */
    @FXML
    private TableColumn<Studente, String> nomeTab;



    /**Funzione iniziale per settare le colonne della tabella di visualizzazione degli studenti*/
    @FXML
    void initialize(){

        matricolaTab.setCellValueFactory(new PropertyValueFactory<>("matricola"));
        datanascitaTab.setCellValueFactory(new PropertyValueFactory<>("dataNascita"));
        nomeTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognomeTab.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        residenzaTab.setCellValueFactory(new PropertyValueFactory<>("residenza"));
        cdsTab.setCellValueFactory(new PropertyValueFactory<>("pianoStudi"));
        TipoTabella<Studente> tab = new TipoTabella<>(new TabellaStudente());
        tableViewStudente.setItems(tab.getElements());
    }
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/segreteria.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
    * funzione per la ricerca degli studenti nel db andando a restituire i risultati trovati a partire dai valori inseriti nei vari form
    * */
    @FXML
    void searchStudente() {
        String matricola = searchMatricola.getText();
        String nome = searchNome.getText();
        String cognome = searchCognome.getText();

        tableViewStudente.getItems().clear();
        ObservableList<Studente> data = FXCollections.observableArrayList();

        try {
            Database db = new Database();
            String sql;


            if (!matricola.isEmpty() || !nome.isEmpty() || !cognome.isEmpty()) {
                if (matricola.isEmpty()) {
                    sql = "SELECT * FROM studente WHERE nome LIKE '%" + nome + "%' AND cognome LIKE '%" + cognome + "%'";
                } else {
                    sql = "SELECT * FROM studente WHERE nome LIKE '%" + nome + "%' AND cognome LIKE '%" + cognome + "%' AND matricola = " + Integer.parseInt(matricola);
                }
            }
            else {
                sql = "SELECT * FROM studente";
            }

            ResultSet rs = db.query(sql);

            while (rs.next()) {
                data.add(new Studente(rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            searchMatricola.clear();
            searchNome.clear();
            searchCognome.clear();
        }

        tableViewStudente.setItems(data);


    }
}
