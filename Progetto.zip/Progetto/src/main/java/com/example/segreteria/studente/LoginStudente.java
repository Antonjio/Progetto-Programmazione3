package com.example.segreteria.studente;

import singleton.pattern.SessionStu;
import command.pattern.Studente;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Controller per la pagina di login dello studente
 *
 */
public class LoginStudente {
    /**
     * campo per inserire la matricola dello studente
     */

    @FXML
    private TextField matricola;
    /**
     * campo per inserire la password dello studente
     */

    @FXML
    private PasswordField passDoc;
    /**
     * istanza della classe Database
     */
    private Database db;

    @FXML
    void initialize() {

        try {
            db = new Database();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/homepage.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }


    /**
    * funzione per il login dello studente con gestione degli errori quando le credenziali sono errate
     * @param event evento che scatena la funzione
     * @throws Exception eccezione che viene lanciata quando si verifica un errore
    * */
    @FXML
    void loginStudente(ActionEvent event) throws Exception, SQLException {

        ResultSet rs = db.query("select * from studente where matricola = '" + Integer.parseInt(matricola.getText()) + "' and password = SHA2('" + passDoc.getText() + "',256)");
        if (rs.next()) {
            Studente stu = new Studente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
            stu.setMatricola(Integer.parseInt(matricola.getText()));
            stu.setPassword(passDoc.getText());
            SessionStu.getIstanza().setStudente(stu);
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/studente.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setResizable(false);
            window.setScene(tableViewScene);
            window.show();
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setHeaderText(null);
            alert.setContentText("Email o password errati");
            alert.show();
        }
    }
}
