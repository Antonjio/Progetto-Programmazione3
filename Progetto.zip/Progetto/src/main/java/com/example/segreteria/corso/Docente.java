package com.example.segreteria.corso;

/**
 * Classe che rappresenta un docente.
 */
public class Docente {
    private String nome;

    private String pass;

    private String corso;
    private String email;


    public Docente() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Metodi getter e setter per 'pass'
    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    // Metodi getter e setter per 'corso'
    public String getCorso() {
        return corso;
    }

    public void setCorso(String corso) {
        this.corso = corso;
    }

    // Metodi getter e setter per 'email'
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}

