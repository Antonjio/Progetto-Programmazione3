package com.example.segreteria.docente;

import com.example.segreteria.corso.Docente;
import singleton.pattern.SessionDoc;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * Classe per il controllo della scena di login del docente
 */
public class LoginDocente {
    /**
     * TextField per l'inserimento dell'email del docente
     */
    @FXML
    private TextField emailDoc;
    /**
     * TextField per l'inserimento della password del docente
     */

    @FXML
    private PasswordField passDoc;

    private Database db;

    /**connesione al db come prima operazione di quando si apre la scena
     * @throws Exception eccezione per la connessione al db
     */
    @FXML
    void initialize() {

        try {
            db = new Database();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**funzione per tornare alla homepage
     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/homepage.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**controllo per il login di email e password di un docente con apertura nuova scena in caso di successo o errore in caso di credenziali sbagliate
     * @param event evento che scatena la funzione di login
     * @throws Exception eccezione per la connessione al db
     */
    @FXML
    void loginDocente(ActionEvent event) throws Exception {


        ResultSet rs = db.query("select * from docente where email = '" + emailDoc.getText() + "' and password = SHA2('" + passDoc.getText() + "',256)");
        if (rs.next()) {
            Docente doc = new Docente();
            doc.setEmail(emailDoc.getText());
            doc.setPass(passDoc.getText());
            SessionDoc.getIstanza().setDocente(doc);
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/docente.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setResizable(false);
            window.setScene(tableViewScene);
            window.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setHeaderText(null);
            alert.setContentText("Email o password errati");
            alert.show();
        }
    }
}
