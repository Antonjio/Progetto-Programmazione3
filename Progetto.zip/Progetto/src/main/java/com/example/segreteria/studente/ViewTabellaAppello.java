package com.example.segreteria.studente;


import com.example.segreteria.corso.Appello;
import singleton.pattern.SessionStu;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import strategy.pattern.TabellaAppello;
import strategy.pattern.TipoTabella;

import java.io.IOException;
import java.sql.PreparedStatement;

/**
 * classe per la visualizzazione degli appelli disponibili
 */
public class ViewTabellaAppello {
    /**
     * colonna del nome dell' appello
     */
    @FXML
    private TableColumn<Appello, String> nomeAppelloTab;
    /**
     * colonna della data dell' appello
     */
    @FXML
    private TableColumn<Appello, java.sql.Date> dataAppelloTab;

    /**
     * colonna del docente dell' appello
     */
    @FXML
    private TableColumn<Appello, String> docenteAppelloTab;

    /**
     * colonna del corso dell' appello
     */
    @FXML
    private TableColumn<Appello, String> corsoAppelloTab;

    /**
     * colonna dell' id dell' appello
     */
    @FXML
    private TableColumn<Appello, Integer> idAppelloTab;

    /**
     * tabella degli appelli disponibili
     */
    @FXML
    private TableView<Appello> tableViewAppello;

    /**
     * bottone per prenotare l'appello
     */
    @FXML
    private Button prenota;

    /**
     * appello selezionato
     */
    private Appello selectedAppello;


    /**inizializzo le colonne della tabella per la visualizzazione degli appelli disponibili
     */
    @FXML
    void initialize() {

        prenota.setVisible(false);
        idAppelloTab.setCellValueFactory(new PropertyValueFactory<>("id"));
        dataAppelloTab.setCellValueFactory(new PropertyValueFactory<>("data"));
        nomeAppelloTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        docenteAppelloTab.setCellValueFactory(new PropertyValueFactory<>("docente"));
        corsoAppelloTab.setCellValueFactory(new PropertyValueFactory<>("corso"));
        TipoTabella<Appello> tab = new TipoTabella<>(new TabellaAppello());
        tableViewAppello.setItems(tab.getElements());
        tableViewAppello.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedAppello = newSelection;
                prenota.setVisible(true);
            } else {
                selectedAppello = null;
            }
        });
    }

    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/studente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * funzione per gestire la prenotazione ad un appello che inserisce i dati all' interno della tabella Prenotazione nel db
     */
    @FXML
    void handlePrenotazione() {

        try {
            String q = "insert into prenotazione (idappellofk, matricolafk) values (?,?)";
            Database db = new Database();
            PreparedStatement preparedStatement = db.insert(q);
            preparedStatement.setInt(1, selectedAppello.getId());
            preparedStatement.setInt(2, SessionStu.getIstanza().getStudente().getMatricola());
            preparedStatement.execute();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            tableViewAppello.getItems().remove(selectedAppello);
            if (tableViewAppello.getItems().isEmpty()) {
                prenota.setVisible(false);
            }
        }

    }

}
