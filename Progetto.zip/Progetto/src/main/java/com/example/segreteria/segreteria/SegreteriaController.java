package com.example.segreteria.segreteria;

import command.pattern.Studente;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.PreparedStatement;

/**
 * Classe che gestisce la scena della segreteria
 */

public class SegreteriaController {

    /**
     * campo di testo per inseriro il cognome dello studente
     */

    @FXML
    private TextField cognomeStu;

    /**
     * campo di testo per inseriro la residenza dello studente
     */

    @FXML
    private TextField residenza;

    /**
     * campo di testo per inseriro il corso di studi dello studente
     */

    @FXML
    private TextField cds;

    /**
     * campo di testo per inseriro la matricola dello studente
     */
    @FXML
    private TextField matricola;

    /**
     * campo di testo per inseriro la password dello studente
     */
    @FXML
    private PasswordField password;

    /**
     * campo di testo per inseriro la data di nascita dello studente
     */

    @FXML
    private TextField dataNascita;

    /**
     * campo di testo per inseriro il nome dello studente
     */

    @FXML
    private TextField nomeStu;


    /**
     * campo di testo per inseriro il nuovo corso di studi dello studente
     */
    @FXML
    private TextField newcds;

    /**
     * campo di testo per inseriro la nuova matricola dello studente
     */
    @FXML
    private TextField upmatricola;

    private Database db;

    /**connessione al db all'apertura della scena
     * @throws Exception eccezione per la connessione al db
     */
    @FXML
    void initialize() {
        try {
            db = new Database();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**logout della segreteria
     * torna alla schermata iniziale
     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void logout(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/homepage.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**funzione per tornare alla schemrata della segreteria

     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/segreteria.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**apertura della scena per inserire un nuovo studente

     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void openNuovoStudente(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/nuovostudente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**apertura scena per cercare uno studente

     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void openSearchStudent(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/cercastudente1.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**apertura scena per cambiare piano studi ad uno studente
     * @param event evento che scatena la funzione
     * @throws IOException eccezione per la scena
     */
    @FXML
    void openUpdateCDS(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/upstudent.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * funzione per l'inserimento di un nuovo studente
     * andando a gestire gli erorri di inserimenti dovuti ad esempio matricola già presente o corso di studi non valido
     * */
    @FXML
    void addStudent() {
        try {
            Studente stu = new Studente();
            stu.setNome(nomeStu.getText());
            stu.setMatricola(Integer.parseInt(matricola.getText()));
            stu.setPassword(password.getText());
            stu.setCognome(cognomeStu.getText());
            stu.setDataNascita(dataNascita.getText());
            stu.setResidenza(residenza.getText());
            stu.setPianoStudi(cds.getText());

            String q = "insert into segreteria.studente (matricola, nome, cognome, data_nascita, residenza, piano_di_studi, password)" + "values (?,?,?,?,?,?,SHA2(?,256))";

            PreparedStatement preparedStatement = db.insert(q);

            preparedStatement.setInt(1, stu.getMatricola());
            preparedStatement.setString(2, stu.getNome());
            preparedStatement.setString(3, stu.getCognome());
            preparedStatement.setDate(4, stu.getDataNascita());
            preparedStatement.setString(5, stu.getResidenza());
            preparedStatement.setString(6, stu.getPianoStudi());
            preparedStatement.setString(7, stu.getPassword());

            preparedStatement.execute();
            nomeStu.clear();
            matricola.clear();
            password.clear();
            cognomeStu.clear();
            dataNascita.clear();
            residenza.clear();
            cds.clear();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Inserito");
            alert.setHeaderText(null);
            alert.setContentText("Nuovo studente inserito correttamente");
            alert.show();

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setContentText("Non è stato possibile inserire il nuovo studente");
            alert.show();
            System.out.println("ERRORE: " + e.getMessage());
        }

    }

    /**
     * funzione per cambiare il corso di studi ad uno studnete gestendo il caso in cui lo studente viene iscritto ad un corso non esistente
     * */

    @FXML
    void upCDS() {
        try {
            Studente stu = new Studente();
            stu.setMatricola(Integer.parseInt(upmatricola.getText()));
            stu.setPianoStudi(newcds.getText());

            String q = "update studente set piano_di_studi = '" + stu.getPianoStudi() + "' where matricola = '" + stu.getMatricola() + "'";

            db.update(q);
            newcds.clear();
            upmatricola.clear();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Modificato");
            alert.setHeaderText(null);
            alert.setContentText("Nuovo corso di studi modificato correttamente");
            alert.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Errore");
            alert.setContentText("Non è stato possibile modificare il nuovo corso di studi dello studente");
            alert.show();
            System.out.println("ERRORE: " + e.getMessage());
        }

    }

}
