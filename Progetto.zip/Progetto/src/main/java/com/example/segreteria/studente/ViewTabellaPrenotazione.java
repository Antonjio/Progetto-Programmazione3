package com.example.segreteria.studente;

import com.example.segreteria.corso.Appello;
import singleton.pattern.SessionStu;
import singleton.pattern.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import strategy.pattern.TabellaPrenotazione;
import strategy.pattern.TipoTabella;

import java.io.IOException;

/** Controller della view ViewTabellaPrenotazione
 */
public class ViewTabellaPrenotazione {
    /**
     * colanna nome prenotazione
     */
    @FXML
    private TableColumn<Appello, String> nomePrenotazioneTab;
    /**
     * colanna data prenotazione
     */
    @FXML
    private TableColumn<Appello, java.sql.Date> dataPrenotazioneTab;
    /**
     * colanna id prenotazione
     */
    @FXML
    private TableColumn<Appello, Integer> idPrenotazioneTab;
    /**
     * tabella prenotazione
     */
    @FXML
    private TableView<Appello> tableViewPrenotazione;
    /**
     * bottone per annullare una prenotazione
     */
    @FXML
    private Button annulla;
    /**
     * appello selezionato
     */
    private Appello selectedAppello;

    /**
    * Inizializzo le colonne per la visualizzazione delle prenotazioni
    * andando pure ad eliminare le prenotazioni ormai passate perchè gli appelli sono scaduti
    * */
    @FXML
    void initialize(){
        annulla.setVisible(false);
        try {
            String q = "DELETE prenotazione.* FROM prenotazione " +
                    "JOIN appello ON prenotazione.idappellofk = appello.id " +
                    "WHERE prenotazione.matricolafk = " + SessionStu.getIstanza().getStudente().getMatricola() +
                    " AND appello.data < CURRENT_DATE";
            Database db = new Database();
            db.update(q);

        } catch (Exception e) {
            e.printStackTrace();
        }
        idPrenotazioneTab.setCellValueFactory(new PropertyValueFactory<>("id"));
        dataPrenotazioneTab.setCellValueFactory(new PropertyValueFactory<>("data"));
        nomePrenotazioneTab.setCellValueFactory(new PropertyValueFactory<>("nome"));
        TipoTabella<Appello> tab = new TipoTabella<>(new TabellaPrenotazione());
        tableViewPrenotazione.setItems(tab.getElements());
        tableViewPrenotazione.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedAppello = newSelection;
                annulla.setVisible(true);
            } else {
                selectedAppello = null;
            }
        });
    }

    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/studente.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }
    /**
    * funzione per cancellare una prenotazione ad un appello
    * */
    @FXML
    void cancelPrenotazione(){

        try {
            String q = "delete from prenotazione where idappellofk = " + selectedAppello.getId()+" and matricolafk = "+SessionStu.getIstanza().getStudente().getMatricola()+ " ";
            Database db = new Database();
            db.update(q);

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            tableViewPrenotazione.getItems().remove(selectedAppello);
            if (tableViewPrenotazione.getItems().isEmpty()){
                annulla.setVisible(false);
            }
        }

    }

}
