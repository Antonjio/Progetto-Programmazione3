package com.example.segreteria.studente;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller della view Studente
 */
public class StudenteController {

    @FXML
    void logout(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/homepage.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**apertura scena degli appelli
     * @param event evento che scatena l'azione
     * @throws IOException eccezione lanciata in caso di errore di apertura della scena
     */
    @FXML
    void handleViewAppello(ActionEvent event) throws IOException{
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/viewAppello.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**apertura scena libretto
     * @param event evento che scatena l'azione
     * @throws IOException eccezione lanciata in caso di errore di apertura della scena
     */
    @FXML
    void openLibretto(ActionEvent event) throws IOException{
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/viewEsame.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**apertura scena esito esame
     * @param event evento che scatena l'azione
     * @throws IOException eccezione lanciata in caso di errore di apertura della scena
     */
    @FXML
    void handleOpenEsitoEsame(ActionEvent event) throws IOException{
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/esitoEsame.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**apertura scena prenotazioni
     * @param event evento che scatena l'azione
     * @throws IOException eccezione lanciata in caso di errore di apertura della scena
     */
    @FXML
    void handleViewPrenotazioni(ActionEvent event) throws IOException{
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("/com/example/segreteria/viewPrenotazione.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }
}
