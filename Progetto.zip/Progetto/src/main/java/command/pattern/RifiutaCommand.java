package command.pattern;

import com.example.segreteria.corso.Esame;

import java.sql.SQLException;

/**ConcreteCommand che implementa l'interfaccia Command che in questo caso si chiama "Scelta"
 */
public class RifiutaCommand implements Scelta{
    /**
     * studente che effettua la scelta
     */
    private Studente studente;
    /**
     * esame da rifiutare
     */
    private Esame esame;

    /**costruttore con parametri per impostare lo studente in sessione e l'esame da rifiutare
     * @param studente che rifiuta l'esame
     * @param esame da rifiutare
     */
    public RifiutaCommand(Studente studente, Esame esame){
        this.studente = studente;
        this.esame = esame;
    }

    /**execute che richiama il metodo di "studente"(receiver) che rifiuta l'esame
     */
    @Override
    public void execute() throws SQLException {
        studente.rifiutaEsame(esame);
    }
}

