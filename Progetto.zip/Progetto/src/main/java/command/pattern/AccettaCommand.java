package command.pattern;

import com.example.segreteria.corso.Esame;

import java.sql.SQLException;

/**ConcreteCommand che implementa l'interfaccia Command che in questo caso si chiama "Scelta"
 */
public class AccettaCommand implements Scelta{
    /**
     * studente che accetta l'esame
     */
    private Studente studente;
    /**
     * esame da accettare
     */
    private Esame esame;

    /**costruttore con parametri per impostare lo studente in sessione e l'esame da acccettare
     * @param studente studente in sessione
     * @param esame esame da accettare
     */
    public AccettaCommand(Studente studente, Esame esame){
        this.studente = studente;
        this.esame = esame;
    }

    /**execute che richiama il metodo della classe "Studente"(receiver) che accetta l'esame
     */
    @Override
    public void execute() throws SQLException {
        studente.accettaEsame(esame);
    }

}
