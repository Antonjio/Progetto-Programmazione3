package command.pattern;

import com.example.segreteria.corso.Esame;
import singleton.pattern.Database;
import singleton.pattern.SessionStu;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;


/**Classe receiver del Command Pattern
 */
public class Studente {
    /**
     * matricola dello studente
     */
    int matricola;
    /**
     * nome dello studente
     */
    private String nome;
    /**
     * cognome dello studente
     */
    private String cognome;
    /**
     * data di nascita dello studente
     */
    private java.sql.Date dataNascita;
    /**
     * password dello studente
     */
    private String password;
    /**
     * residenza dello studente
     */
    private String residenza;
    /**
     * piano di studi dello studente
     */
    private String pianoStudi;



    public Studente(){}

    /**costruttore con parametri e utilizzo del metodo parse di simpledateformat per convertire una stringa in una data
     * @param matricola matricola dello studente
     * @param nome nome dello studente
     * @param cognome cognome dello studente
     * @param dataNascita data di nascita dello studente
     * @param residenza residenza dello studente
     * @param pianoStudi piano di studi dello studente
     * @throws ParseException eccezione che viene lanciata quando si verifica un errore durante il parsing di una stringa in una data
     */
    public Studente(int matricola, String nome, String cognome, String dataNascita,String residenza, String pianoStudi) throws ParseException {
        this.matricola = matricola;
        this.nome = nome;
        this.cognome = cognome;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(dataNascita);
        // Converti java.util.Date in java.sql.Date
        this.dataNascita = new java.sql.Date(utilDate.getTime());
        this.residenza = residenza;
        this.pianoStudi = pianoStudi;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCognome() {
        return this.cognome;
    }

    public String getPianoStudi() {
        return pianoStudi;
    }
    public java.sql.Date getDataNascita() {
        return dataNascita;
    }


    /**Conferma a livello di database del voto inserito dal docente
     * @param esame esame da confermare
     * @throws SQLException eccezione che viene lanciata quando si verifica un errore durante l'accesso al database
     */
    public void accettaEsame(Esame esame) throws SQLException {
        String q = "update esame_superato set confermato = 1 where matricolafk = "+ SessionStu.getIstanza().getStudente().getMatricola()+" and nome = '"+ esame.getNome() +"'";
        Database db = new Database();
        db.update(q);
    }

    /**eliminazione del voto dal database inserito dal docente
     * @param esame esame da rifutare
     * @throws SQLException eccezione che viene lanciata quando si verifica un errore durante l'accesso al database
     */
    public void rifiutaEsame(Esame esame) throws SQLException {
        String q = "delete from esame_superato where matricolafk = "+ SessionStu.getIstanza().getStudente().getMatricola()+" and nome = '"+ esame.getNome() +"'";
        Database db = new Database();
        db.update(q);
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public void setDataNascita(String dataNascita) throws ParseException{
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date utilDate = dateFormat.parse(dataNascita);
        // Converti java.util.Date in java.sql.Date
        this.dataNascita = new java.sql.Date(utilDate.getTime());
    }

    public void setPianoStudi(String pianoStudi) {
        this.pianoStudi = pianoStudi;
    }

    public void setResidenza(String residenza){
        this.residenza = residenza;
    }
    public void setMatricola(int matricola){
        this.matricola = matricola;
    }
    public void setPassword(String password){
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public int getMatricola(){
        return matricola;
    }
    public String getResidenza(){
        return residenza;
    }
}