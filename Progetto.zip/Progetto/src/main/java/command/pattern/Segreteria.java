package command.pattern;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;

/**Questa classe sarebbe la invoker del Command pattern
* la quale inserisce tramite il metodo "placeScelta" tutte le scelte dello studente
* per poi essere eseguite al momento del richiamo del metodo "executeScelta"
 */
public class Segreteria {
    public String username;
    public String password;
    private Queue<Scelta> coda = new LinkedList<>();
    public void placeScelta(Scelta scelta){
        coda.add(scelta);
    }

    public void executeScelta() throws SQLException {
        while (!coda.isEmpty()) {
            Scelta temp = coda.remove();
            temp.execute();
        }
    }

    public void setUsername(String username){
        this.username = username;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public String getPassword() {
        return password;
    }
    public String getUsername() {
        return username;
    }
}