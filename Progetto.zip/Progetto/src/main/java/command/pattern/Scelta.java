package command.pattern;

import java.sql.SQLException;

/**interfaccia da implementare per i ConcreteCommand del Command Pattern
 */
public interface Scelta {
    void execute() throws SQLException;
}
