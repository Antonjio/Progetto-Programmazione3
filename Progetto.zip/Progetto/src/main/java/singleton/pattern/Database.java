package singleton.pattern;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Questa classe gestisce le operazioni che si possono effettuare sul database.
 */
public class Database {
    private Connessione cs;

    /**
     * Nel costruttore viene inizializzata la connessione al database mediante il metodo della classe
     * ConnessioneSingleton che si occupa di restituire l'unica istanza di connessione al database.
     */
    public Database() {
        cs = Connessione.getIstanza();
    }

    public ResultSet query(String q) throws SQLException {
        Statement state = cs.getConnessione().createStatement();
        return state.executeQuery(q);
    }

    /**
     * Metodo per ottenere un oggetto PreparedStatement pronto per l'esecuzione di una query di inserimento
     * nel database.
     * @param q la stringa che rappresenta la query di inserimento.
     */
    public PreparedStatement insert(String q) throws SQLException {
        return cs.getConnessione().prepareStatement(q);
    }

    /**
     * Metodo per effettuare un'eliminazione dal database a partire dalla stringa passata in input
     * @param q la stringa che rappresenta la query di eliminazione/update.
     */
    public void update(String q) throws SQLException {
        Statement state = cs.getConnessione().createStatement();
        state.executeUpdate(q);
    }
}