package singleton.pattern;

import command.pattern.Studente;

/**
 * Classe che viene gestita come il pattern Singleton, che permette di avere un'unica istanza.
 */
public class SessionStu {

    /**
     * Attributo che rappresenta l'istanza della classe.
     */
    private static SessionStu istanza;
    /**
     * Attributo che rappresenta lo studente in sessione.
     */
    private Studente studente;


    //costruttore privato per avere non farlo istanziare da altre classi
    private SessionStu() {
    }

    //metodo che restituisce l'istanza della classe
    public static synchronized SessionStu getIstanza() {
        if (istanza == null) {
            istanza = new SessionStu();
        }
        return istanza;
    }

    //imposto lo studente in sessione

    public void setStudente(Studente s) {
        this.studente = s;
    }

    //ottengo lo studente in sessione
    public Studente getStudente() {
        return studente;
    }

}

