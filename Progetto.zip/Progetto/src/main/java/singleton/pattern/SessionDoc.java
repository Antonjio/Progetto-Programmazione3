package singleton.pattern;

import com.example.segreteria.corso.Docente;

/**
 * Classe che viene gestita come il pattern Singleton, che permette di avere un'unica istanza.
 */
public class SessionDoc {
    /**
     * Attributo che rappresenta l'istanza della classe.
     */
    private static SessionDoc istanza;
    /**
     * Attributo che rappresenta il docente.
     */
    private Docente docente;

    //costruttore privato per avere non farlo istanziare da altre classi
    private SessionDoc() {
    }

    //metodo che restituisce l'istanza della classe
    public static synchronized SessionDoc getIstanza() {
        if (istanza == null) {
            istanza = new SessionDoc();
        }
        return istanza;
    }

    public void setDocente(Docente d) {
        this.docente = d;
    }

    public Docente getDocente() {
        return docente;
    }

}