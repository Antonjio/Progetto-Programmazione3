package singleton.pattern;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe per la gestione della connessione al db
 */

public class Connessione {
    /**
     * istanza di Connessione
     */

    private static Connessione istanza;
    /**
     * variabile di tipo Connection per la connessione al db
     */
    private Connection conn;

    /**
     * Costruttore privato, in modo da impedire la creazione di istanze dirette della classe, al di fuori della
     * classe stessa.
     */
    private Connessione() {}
    public static Connessione getIstanza() {
        if (istanza == null) {
            istanza = new Connessione();
            istanza.conn = istanza.connessione();
        }
        return istanza;
    }
    private Connection connessione() {
        try {
            /**
             * La seguente istruzione permette di caricare il driver JDBC per il database MySQL.
             */
            Class.forName("com.mysql.cj.jdbc.Driver");
            /**
             * La seguente istruzione permette di stabilire la connessione con il database.
             */
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/segreteria","root",
                    "programmazione3");
            System.out.println("Connessione al database riuscita!");
        }
        catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return conn;
    }

    public Connection getConnessione() {
        return conn;
    }
}
